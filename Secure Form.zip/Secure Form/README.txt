step1:i have developed the web application using Xampp server using php and backend as mysql.

step2:i have created the from named formvalid.php file to get the input from the user.
step3:I have done the validation foreach field presented in the form(name, password, confirmpassword, email separately as per the requirement)
step4:I have created a database named "phpcrud" in that database i am using the "register" table to store my data.
