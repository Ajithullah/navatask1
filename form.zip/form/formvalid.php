<?php
$con=new mysqli("localhost","root","","phpcrud");
if(!$con)
{
	die('error in database'.mysqli_error($con));
}




// Define password complexity criteria

if(isset($_POST['submit']))
{
	$Name=$_POST['name'];
	$Password=$_POST['password'];
	$Email=$_POST['email'];


    
    if (strlen($Password) < 8)
     {
        echo '<script>';
	echo ' alert("password at least 8 character" );' ;
    echo  'window.location="formvalid.php" ' ;
    echo '</script>';
 //  header("location:formvalid.php");
	return false;
 
     }
     $email = $_POST['email']; // Assuming the email is submitted via POST method

     $emailExp = '/^[\w\-\.\+\!]+@[a-zA-Z0-9\.\-]+\.[\w\-\.]{2,3}$/';
     
     if (preg_match($emailExp, $email)) {
         // Email is valid
     } else {
        echo '<script>';
         echo 'alart("Please enter a valid email address");';
         echo  'window.location="formvalid.php" ' ;
         echo '</script>';
         header("location:formvalid.php");
         return false;
     }
$check_mail="select * from register where email='$Email'";
$result=mysqli_query($con,$check_mail);

if($result->num_rows>0)
{
	//echo "email already exists";
    echo '<script>';
	echo ' alert("email already exists" );' ;
    echo  'window.location="formvalid.php" ' ;
    echo '</script>';
	return false;
}
else

{
	$query="INSERT INTO `register`(`name`, `password`,`email`) 
	VALUES ('$Name','$Password','$Email')";
	$res=mysqli_query($con,$query);
	if($res)
	{
		//echo "register successfully";
        echo '<script>';
        echo ' alert("register successfully" );' ;
        echo  'window.location="formvalid.php" ' ;
        echo '</script>';
	}
	else
	{
		echo mysqli_error($d);
	}
}
}

?>
<html>
<head>
<title>Form valid </title>
<style>
table{
	background-color:#1E90FF;
	color:white;
	font-weight:bold;
	font-size:20px;
	border-radius:10px;
}
table,th,td{
border:none;
margin:10px;
padding:20px;
}
.button{
padding:10px;
border:none;
background-color:#FAEBD7;
border-radius:5px;
font-size:15px;
font-weight:bold;
}
#color:hover{
    background-color:red;
}
input[type=text],input[type=password]
{
	height:30px;
	border:none;
	border-radius:5px;
}
</style>
<script language="javascript">
function onsubmit_validation()
{
 if(document.form1.name.value=="")
    {
        alert ( "Please fill ur name.");
        document.form1.name.focus();
    
        return false;
    }
 if(document.form1.password.value =="")
    {
        alert ( "enter the password");
        document.form1.password.focus();
        return false;
    }
if(document.form1.con_password.value=="")
    {
        alert ( "enter the re-enter password");
        document.form1.con_password.focus();
        return false;
    }
if((document.form1.password.value) != (document.form1.con_password.value))
    {
        alert ("re-enter password are not same");
        document.form1.pass2.focus();
        return false;
    }
   
 var emailExp=/^[\w\-\.\+\!]+\@[a-zA-Z0-9\.\-]+\.[\w\-\.]{2,3}$/;  
 
   if(document.form1.email.value.match(emailExp))
    {
   
    }  
   else   
   {
   alert("plz enter valid email address");
   return false;
   }
   //alert("Form valid");
   return true;
}
</script>
</head>
<body>
<center>
<form name="form1" method="post"action="formvalid.php">
<h2><center>User Form</center></h2>
<table width="400" height="400">
<tr>
<td>
<label>Name</label>
</td>
<td>
<input type="text" name="name" required="required">
</tr>
<tr>
<td>
 <label>Password</label>
</td>
<td>
<input type="password" name="password"  required="required"></td>
</tr>
<tr>
<td>
<label>Conform Password </label>
</td>
<td>
<input type="password" name="con_password"  required="required">
</tr>

<tr>
<td>
<label>E-Mail </label>
</td>
<td>
<input type="text" name="email"  required="required">
</td>
</tr>

<tr>
<td></td>
<td><button id="color" class="button" name="submit" onclick="onsubmit_validation();">Submit</button>
<input id="color" type="Reset" class="button" name="r1" value="Reset">
</td>
</tr>
</table>
</form>
</center>
</body>
</html>